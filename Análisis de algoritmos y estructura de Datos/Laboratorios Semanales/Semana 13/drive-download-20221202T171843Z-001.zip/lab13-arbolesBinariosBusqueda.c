#include <stdio.h>
#include <stdlib.h>
#include "TDAabb.h"

int main() 
{
	nodoABB* nodo;
	TDAabb* arbolBB=crearABBVacio();
	return 0;
}