#include <stdio.h>
#include <stdlib.h>
#include "TDAarbolBinario.h"

int main() 
{
	TDAarbolBinario* arbolBinario=crearArbolBinarioVacio();
	return 0;
}