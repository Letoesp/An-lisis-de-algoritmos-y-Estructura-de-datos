#include <stdio.h>
#include <stdlib.h>
#include "TDApila.h"

int main()
{
  TDApila* pila;
  return 0;
}
