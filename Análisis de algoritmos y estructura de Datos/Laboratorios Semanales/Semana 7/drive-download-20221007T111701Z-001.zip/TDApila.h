#include <stdio.h>
#include <stdlib.h>

/*------------- estructura de datos -------------*/

typedef struct nodoGenerico
{
   int dato;
   struct nodoGenerico* puntero;
}nodo;

typedef struct
{
  int capacidad;
  int size;
  nodo* tope;
}TDApila;

/*------------- operaciones -------------*/

TDApila* crearPilaVacia(int capacidad)
{
  TDApila* pila=(TDApila*)malloc(sizeof(TDApila));
  pila->capacidad=capacidad;
  pila->size=0;
  pila->tope=NULL;
  return pila;
}

int esPilaVacia(TDApila* pila)
{
  if (pila->size == 0)
    return 1;
  else
    return 0;
}

nodo* tope(TDApila* pila)
{
  return pila->tope;
}


/*------------- Actividad 2 -------------*/
void apilar(TDApila* pila, int dato);
void desapilar(TDApila* pila);


/*------------- Actividad 3 -------------*/
void reversaSecuencia(int* secuencia);


/*------------- Actividad 4 -------------*/
int esPalindroma(int* secuencia);





