#include <stdio.h>
#include <stdlib.h>
#include "TDAlista.h"

int main()
{
  TDAlista* lista=crearListaVacia();
  recorrerLista(lista);
  return 0;
}